# 2025 年第四季度经营复盘

## 星河科技 · 销售运营中心 · 2026 年 1 月

## 核心结论

- 全年营收 4,860 万元，完成目标的 101%

    - 华东区第四季度营收 480 万元，环比增长 17.1%
    - 西南区全年增速 53.3%，为增长最快区域
- 回款周期变长，应收账款周转天数 68 天
    - 需要重点关注前十大客户的续约

<small><span class="docvortex-page-footnote" data-block-type="page_footnote" style="color:#6b7280">讲解要点：先说结论，再说风险，回款问题需要财务部配合。<br>&lt;number&gt;</span></small>

## 区域营收明细（万元）

<table><tbody><tr><td rowspan="2"><p>区域</p></td><td colspan="2"><p>上半年</p></td><td colspan="2"><p>下半年</p></td><td rowspan="2"><p>合计</p></td></tr><tr><td><p>Q1</p></td><td><p>Q2</p></td><td><p>Q3</p></td><td><p>Q4</p></td></tr><tr><td><p>华东</p></td><td><p>320</p></td><td><p>360</p></td><td><p>410</p></td><td><p>480</p></td><td><p>1570</p></td></tr><tr><td><p>华南</p></td><td><p>280</p></td><td><p>300</p></td><td><p>350</p></td><td><p>390</p></td><td><p>1320</p></td></tr><tr><td><p>华北</p></td><td><p>260</p></td><td><p>270</p></td><td><p>330</p></td><td><p>380</p></td><td><p>1240</p></td></tr><tr><td><p>西南</p></td><td><p>150</p></td><td><p>170</p></td><td><p>200</p></td><td><p>230</p></td><td><p>750</p></td></tr></tbody></table>

## 季度营收对比（原生图表）

![](images/page_3_chart_1.jpg)

<details>
<summary>chart content</summary>

|  | 华东 | 华南 | 华北 | 西南 |
| --- | --- | --- | --- | --- |
| Q1 | 320 | 280 | 260 | 150 |
| Q2 | 360 | 300 | 270 | 170 |
| Q3 | 410 | 350 | 330 | 200 |
| Q4 | 480 | 390 | 380 | 230 |
</details>

![](images/page_3_chart_2.jpg)

<details>
<summary>chart content</summary>

|  | 全年占比 |
| --- | --- |
| 华东 | 1570 |
| 华南 | 1320 |
| 华北 | 1240 |
| 西南 | 750 |
</details>

<small><span class="docvortex-page-footnote" data-block-type="page_footnote" style="color:#6b7280">柱状图和饼图都是 PowerPoint 原生图表，数据保存在文件内部。<br>&lt;number&gt;</span></small>

## 报销流程与改进措施

![](images/page_4_image_1.jpg)

<details>
<summary>image content</summary>

image.png
</details>

图：报销审批流程（图片）

**改进一**

审批节点从 5 个减少到 4 个

**改进二**

发票自动识别，减少手工录入

## 趋势图（仅图片，检验图片中的文字识别）

![](images/page_5_image_1.png)

<details>
<summary>image content</summary>

image.png
</details>

谢谢！

联系人：运营中心 王芳  分机 8021