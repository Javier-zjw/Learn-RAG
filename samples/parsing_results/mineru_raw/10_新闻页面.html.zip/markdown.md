<a id="html-e6d33b3943373efe55de"></a>
# 星河科技发布数据平台 2.3 版本

发布时间：2026-01-15　作者：产品部

1 月 15 日，星河科技正式发布数据平台 2.3 版本。新版本引入**实时计算引擎**， 查询延迟降低 *40%*，并支持公式 `E = mc²` 这类行内代码的展示。

<a id="html-130718db8cf336eea76e"></a>
## 主要更新

1. 实时计算引擎
    - 支持 Kafka 与 Pulsar 数据源
    - 窗口聚合延迟低于 1 秒
2. 新增 12 种图表类型
3. 权限模型升级为基于角色的访问控制（RBAC）

<a id="html-50161f355f07f9c2e3ae"></a>
## 版本价格

<table> <tr><th rowspan="2">版本</th><th colspan="2">订阅价格（元）</th><th rowspan="2">技术支持</th></tr> <tr><th>月费</th><th>年费</th></tr> <tr><td>基础版</td><td>999</td><td>9,990</td><td>无</td></tr> <tr><td>标准版</td><td>2,999</td><td>29,990</td><td>工作日</td></tr> <tr><td>企业版</td><td colspan="2">面议</td><td>7×24 小时</td></tr> </table>

<a id="html-f1120d137f5e155c79b6"></a>
### 升级命令

```batch
dataplat upgrade --to 2.3 --backup /data/backup
```

“新版本让我们的日报生成时间从 2 小时缩短到 10 分钟。” —— 某零售客户

![](images/page_0_image_10.png)

图 1 各区域季度营收