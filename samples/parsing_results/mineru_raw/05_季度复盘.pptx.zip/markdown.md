# 2025 年第四季度经营复盘

星河科技 · 销售运营中心 · 2026 年 1 月

## 核心结论

- 全年营收 4,860 万元，完成目标的 101%
    - 华东区第四季度营收 480 万元，环比增长 17.1%
    - 西南区全年增速 53.3%，为增长最快区域
- 回款周期变长，应收账款周转天数 68 天
    - 需要重点关注前十大客户的续约

<small><span class="docvortex-page-footnote" data-block-type="page_footnote" style="color:#6b7280">讲解要点：先说结论，再说风险，回款问题需要财务部配合。</span></small>

## 区域营收明细（万元）

<table border="1">
  <tr>
    <th rowspan="2">区域</th>
    <th colspan="2">上半年</th>
    <th colspan="2">下半年</th>
    <th rowspan="2">合计</th>
  </tr>
  <tr>
    <td>Q1</td>
    <td>Q2</td>
    <td>Q3</td>
    <td>Q4</td>
  </tr>
  <tr>
    <td>华东</td>
    <td>320</td>
    <td>360</td>
    <td>410</td>
    <td>480</td>
    <td>1570</td>
  </tr>
  <tr>
    <td>华南</td>
    <td>280</td>
    <td>300</td>
    <td>350</td>
    <td>390</td>
    <td>1320</td>
  </tr>
  <tr>
    <td>华北</td>
    <td>260</td>
    <td>270</td>
    <td>330</td>
    <td>380</td>
    <td>1240</td>
  </tr>
  <tr>
    <td>西南</td>
    <td>150</td>
    <td>170</td>
    <td>200</td>
    <td>230</td>
    <td>750</td>
  </tr>
</table>

## 季度营收对比（原生图表）

|  | 华东 | 华南 | 华北 | 西南 |
| --- | --- | --- | --- | --- |
| Q1 | 320 | 280 | 260 | 150 |
| Q2 | 360 | 300 | 270 | 170 |
| Q3 | 410 | 350 | 330 | 200 |
| Q4 | 480 | 390 | 380 | 230 |

|  | 全年占比 |
| --- | --- |
| 华东 | 1570 |
| 华南 | 1320 |
| 华北 | 1240 |
| 西南 | 750 |

<small><span class="docvortex-page-footnote" data-block-type="page_footnote" style="color:#6b7280">柱状图和饼图都是 PowerPoint 原生图表，数据保存在文件内部。</span></small>

## 报销流程与改进措施

![](images/page_4_image_1.jpg)

<details>
<summary>image content</summary>

image.png
</details>

图：报销审批流程（图片）

**改进一**

审批节点从 5 个减少到 4 个

**改进二**

发票自动识别，减少手工录入

## 趋势图（仅图片，检验图片中的文字识别）

![](images/page_5_image_1.png)

<details>
<summary>image content</summary>

image.png
</details>

谢谢！

联系人：运营中心 王芳  分机 8021