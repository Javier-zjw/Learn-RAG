季度营收趋势

![](images/page_0_chart_1.jpg)