# Hybrid Retrieval with Reciprocal Rank Fusion

A. Researcher, B. Engineer | Galaxy Tech Lab

Abstract. We study how dense and sparse retrievers can be combined. Reciprocal Rank Fusion (RRF) merges ranked lists without score calibration and improves nDCG@10 by 4.1 points on our benchmark.

## 1 Method

Given ranked lists from m retrievers, the fused score of document d is defined in Eq. (1):

$$
s (d) = \sum_ {i = 1} ^ {m} \frac {w _ {i}}{k + r _ {i} (d)}\tag{1}
$$

BM25 scores a term t in document d with the saturation function in Eq. (2):

$$
\operatorname{bm} 2 5 (t, d) = \operatorname{idf} (t) \cdot \frac {f (t , d) \left(k _ {1} + 1\right)}{f (t , d) + k _ {1} \left(1 - b + b \frac {| d |}{\operatorname{avgdl}}\right)}\tag{2}
$$

## 2 Results

Table 1: Retrieval quality on the test set.

| Method | Recall@10 | MRR@10 | nDCG@10 |
| --- | --- | --- | --- |
| BM25 | 0.712 | 0.534 | 0.581 |
| Dense | 0.768 | 0.571 | 0.619 |
| Hybrid (RRF) | 0.823 | 0.602 | 0.660 |

**Algorithm 1 Reciprocal Rank Fusion**

```txt
Input: ranked lists L1..Lm, weights w, constant k
for each document d in union(L1..Lm) do
    s(d) <- sum_i w_i / (k + rank_i(d))
end for
return documents sorted by s(d) descending
```

## References

[1] G. Cormack, C. Clarke, S. Buettcher. Reciprocal rank fusion outperforms Condorcet and individual rank learning methods. SIGIR 2009.

[2] S. Robertson, H. Zaragoza. The probabilistic relevance framework: BM25 and beyond. 2009.